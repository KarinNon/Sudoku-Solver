import React, { use, useState } from "react";
import "./App.css";

const emptyBoard = Array(9).fill().map(() => Array(9).fill(""));

function App() {
      const [board, setBoard] = useState(emptyBoard);
      const [invalidCell, setInvalidCell] = useState(
            Array(9).fill().map(() => Array(9).fill(false))
      );
      const [isSolved, setIsSolved] = useState(false);

      const handleChange = (row, col, value) => {
            setIsSolved(false);

            if (value === "" || (/^[1-9]$/.test(value))) {
                  const newBoard = board.map(r => [...r]);
                  newBoard[row][col] = value;
                  setBoard(newBoard);
                  checkBoard(newBoard);
            }
      };

      const isValid = (board, row, col, num) => {
            for (let i = 0; i < 9; i++) {
                  if (board[row][i] === num || board[i][col] === num) return false;
            }

            const startRow = row - (row % 3);
            const startCol = col - (col % 3);

            for (let i = 0; i < 3; i++) {
                  for (let j = 0; j < 3; j++) {
                        if (board[startRow + i][startCol + j] === num) return false;
                  }
            }

            return true;
      };

      const checkBoard = (boardToCheck) => {
            const invalid = Array(9).fill().map(() => Array(9).fill(false));
            const tmpBoard = boardToCheck.map(r => [...r]);
            let error = false;
            for (let r = 0; r < 9; r++) {
                  for (let c = 0; c < 9; c++) {
                        const value = boardToCheck[r][c];
                        if (value != "") {
                              tmpBoard[r][c] = "";
                              const isError = !isValid(tmpBoard, r, c, value);
                              tmpBoard[r][c] = value;

                              if (isError) {
                                    invalid[r][c] = true;
                                    error = true;
                              }
                        }
                  }
            }
            
            setInvalidCell(invalid);
            return {invalid, error};
      };

      const Solve = () => {
            setIsSolved(false);

            const {error} = checkBoard(board);

            if (error) {
                  alert("Invalid Board");
                  return;
            }

            const newBoard = board.map(r => [...r]);

            const recur = () => {
                  for (let r = 0; r < 9; r++) {
                        for (let c = 0; c < 9; c++) {
                              if (newBoard[r][c] === "") {
                                    for (let num = 1; num <= 9; num++) {
                                          const strNum = num.toString();
                                          if (isValid(newBoard, r, c, strNum)) {
                                                newBoard[r][c] = strNum;
                                                if (recur()) return true;
                                                newBoard[r][c] = "";
                                          }
                                    }
                                    return false;
                              }
                        }
                  }
                  return true;
            };

            if (recur()) {
                  setBoard(newBoard);
                  setIsSolved(true);
            } else {
                  alert("No Solution!");
                  setInvalidCell(Array(9).fill().map(() => Array(9).fill(false)));
            }
      };

      const Reset = () => {
            setBoard(emptyBoard.map(row => [...row]));
            setInvalidCell(Array(9).fill().map(() => Array(9).fill(false)));
            setIsSolved(false);
      }

      return (
            <div className="main">
                  <h1 className="header-text">Sudoku Solver</h1>
                  <div className="sudoku-grid">
                        {board.map((row, rowIndex) => (
                              <div key={rowIndex} className="sudoku-row">
                              {row.map((cell, colIndex) => (
                                    <input
                                          key={`${rowIndex}-${colIndex}`}
                                          type="text"
                                          maxLength="1"
                                          value={cell}
                                          onChange={(e) => handleChange(rowIndex, colIndex, e.target.value)}
                                          className="sudoku-cell"
                                    />
                              ))}
                              </div>
                        ))}
                  </div>
                  <div className="buttonPanel">
                        <button onClick={Reset}>Reset</button>
                        <button onClick={Solve}>Solve</button>
                  </div>
                  <div className="footer-text">
                        Dev by <b><i>Karin Nondetkul</i></b>
                  </div>
            </div>
            );
};

export default App;
